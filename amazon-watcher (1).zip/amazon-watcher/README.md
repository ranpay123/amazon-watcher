# Amazon Watcher 🛒

בוט שעוקב אחרי מוצרים באמזון ושולח התראה ברגע שיש מלאי במחיר שהגדרת.

---

## הגדרה בענן (Railway) — שלב אחר שלב

### שלב 1 — העלאה ל-GitHub
1. נכנסים ל-https://github.com ויוצרים חשבון חינמי (אם אין)
2. לוחצים "New repository" → שם: `amazon-watcher` → Create
3. מעלים את כל הקבצים האלה (app.py, templates/, requirements.txt, Procfile)

### שלב 2 — פתיחת Railway
1. נכנסים ל-https://railway.app
2. "Login with GitHub"
3. "New Project" → "Deploy from GitHub repo" → בוחרים `amazon-watcher`
4. Railway מזהה אוטומטית ומפעיל את האפליקציה

### שלב 3 — הגדרת Gmail להתראות
1. ב-Gmail שלך: הגדרות → אבטחה → "אימות דו-שלבי" (הפעל אם לא פעיל)
2. חפש "App passwords" → צור סיסמת אפליקציה → העתק אותה
3. ב-Railway: Settings → Variables → הוסף:
   - `GMAIL_USER` = האימייל שלך (למשל: myemail@gmail.com)
   - `GMAIL_PASS` = סיסמת האפליקציה שיצרת
   - `NOTIFY_EMAIL` = האימייל שיקבל התראות (יכול להיות אותו אחד)

### שלב 4 — קבלת הכתובת
ב-Railway: Settings → Domains → תקבל כתובת כמו `amazon-watcher-production.up.railway.app`
זאת הכתובת שלך — פותח אותה בטלפון ומוסיף לינקים!

---

## שימוש

1. פותח את הכתובת בדפדפן (או שומר כ-bookmark)
2. מדביק לינק מהוואטסאפ (אמזון או Pokehood)
3. מגדיר מחיר מקסימום
4. לוחץ "הוסף למעקב"
5. **מקבל מייל + כפתור "קנה עכשיו" ישירות לצ'קאוט ברגע שיש מלאי**

---

## מחיר

Railway: $5/חודש לשרת קטן שרץ 24/7.
חלופה חינמית: Render.com (שרת נכבה אחרי 15 דקות של חוסר פעילות — פחות אמין).

---

## הגדרות נוספות

`CHECK_INTERVAL` בקובץ app.py — כמה שניות בין בדיקות (ברירת מחדל: 60).
אפשר להקטין ל-30 שניות לבדיקות מהירות יותר.
